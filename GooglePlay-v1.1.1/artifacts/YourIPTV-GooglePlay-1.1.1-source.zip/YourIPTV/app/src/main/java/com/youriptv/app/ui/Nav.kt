package com.youriptv.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import com.youriptv.app.YourIptvApp
import com.youriptv.app.data.HttpException
import com.youriptv.app.data.ItemKind
import com.youriptv.app.data.MediaItem
import com.youriptv.app.data.Playlist
import org.json.JSONException
import java.io.FileNotFoundException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

object Nav {
    /** The shortcut follows playback state; the currently highlighted guide row is never consulted. */
    fun hasCurrentStream(a: Activity): Boolean {
        val app = YourIptvApp.instance
        if (!app.isTrustedBuild || a.isFinishing || a.isDestroyed) return false
        if (PlayerActivity.hasCurrentStream()) return true
        val item = app.livePlayback.rememberedStream() ?: return false
        return !app.settings.isGroupHidden(item.group)
    }

    fun returnToCurrentStream(a: Activity): Boolean {
        val app = YourIptvApp.instance
        if (!app.isTrustedBuild || a.isFinishing || a.isDestroyed) return false
        if (PlayerActivity.returnToCurrentStream(a)) {
            markStreamReturn(a)
            return true
        }
        val session = app.livePlayback
        val item = session.rememberedStream() ?: return false
        if (app.settings.isGroupHidden(item.group)) return false
        if (Scheduler.recordingUsesOnlyConnection(item.playlistId)) {
            Dialogs.toast(a, "This provider's only connection is being used by a recording.")
            return true
        }
        val playing = session.current
        if (playing?.playlistId == item.playlistId && playing.url == item.url && session.isCurrentAuthorized(item)) {
            return fullscreenPreview(a).also { if (it) markStreamReturn(a) }
        }
        // A released player needs a normal launch and a fresh parental check; remembered PIN grants are not kept.
        open(a, item, session.rememberedQueue(item)) { markStreamReturn(a) }
        return true
    }

    private fun markStreamReturn(a: Activity) {
        if (a is MainActivity) a.markReturningFromCurrentStream()
    }

    /** Opens VOD details or live playback. Locked groups ask before metadata or playback is opened. */
    fun open(a: Activity, item: MediaItem, list: List<MediaItem>, onOpened: (() -> Unit)? = null) {
        val s = YourIptvApp.instance.settings
        if (s.isGroupHidden(item.group)) { Dialogs.toast(a, "This category is hidden."); return }
        val repo = YourIptvApp.instance.repo
        val sourceIdentity = if ((item.kind != ItemKind.LIVE || item.isCatchup) && !item.isLocal)
            repo.playlist(item.playlistId)?.let(repo::sourceIdentity).orEmpty() else ""
        val locked = s.isGroupLocked(item.group)
        // Only a group whose PIN was just entered counts as unlocked in the player.
        val unlocked = if (locked) item.group else null
        val go: () -> Unit = go@ {
            if (sourceIdentity.isNotBlank() && repo.playlist(item.playlistId)?.let(repo::sourceIdentity) != sourceIdentity) {
                Dialogs.toast(a, "The playlist account changed. Reopen this title.")
                return@go
            }
            // Archive entries are finite player items, not catalogue movies. Preserve their archive URL/flag.
            if (item.isCatchup) {
                play(a, listOf(item), 0, unlocked, fromBeginning = true)
                onOpened?.invoke()
                return@go
            }
            when (item.kind) {
                ItemKind.SERIES -> a.startActivity(
                    Intent(a, SeriesActivity::class.java)
                        .putExtra("vod_source_identity", sourceIdentity)
                        .putExtra(SeriesActivity.EXTRA_PLAYLIST, item.playlistId)
                        .putExtra(SeriesActivity.EXTRA_URL, item.url)
                        .putExtra(SeriesActivity.EXTRA_NAME, item.name)
                        .putExtra(SeriesActivity.EXTRA_REMOTE_ID, item.remoteId)
                        .putExtra(SeriesActivity.EXTRA_GROUP, item.group)
                        .putExtra(SeriesActivity.EXTRA_LOGO, item.logo)
                        .putExtra("authorization_stamp", s.restrictionStamp())
                )
                ItemKind.MOVIE -> a.startActivity(
                    Intent(a, MovieDetailsActivity::class.java)
                        .putExtra("vod_source_identity", sourceIdentity)
                        .putExtra(MovieDetailsActivity.EXTRA_PLAYLIST, item.playlistId)
                        .putExtra(MovieDetailsActivity.EXTRA_URL, item.url)
                        .putExtra(MovieDetailsActivity.EXTRA_NAME, item.name)
                        .putExtra(MovieDetailsActivity.EXTRA_REMOTE_ID, item.remoteId)
                        .putExtra(MovieDetailsActivity.EXTRA_GROUP, item.group)
                        .putExtra(MovieDetailsActivity.EXTRA_LOGO, item.logo)
                        .putExtra("authorization_stamp", s.restrictionStamp())
                )
                ItemKind.LIVE -> {
                    val live = list.filter { it.kind == ItemKind.LIVE }.ifEmpty { listOf(item) }
                    play(a, live, live.indexOfFirst { it.url == item.url }.coerceAtLeast(0), unlocked)
                }
                ItemKind.EPISODE -> {
                    if (item.seriesUrl.isNotBlank()) a.startActivity(Intent(a, SeriesActivity::class.java)
                        .putExtra("vod_source_identity", sourceIdentity)
                        .putExtra(SeriesActivity.EXTRA_PLAYLIST, item.playlistId)
                        .putExtra(SeriesActivity.EXTRA_URL, item.seriesUrl)
                        .putExtra(SeriesActivity.EXTRA_NAME, item.seriesName)
                        .putExtra(SeriesActivity.EXTRA_REMOTE_ID, item.seriesRemoteId)
                        .putExtra(SeriesActivity.EXTRA_GROUP, item.group)
                        .putExtra(SeriesActivity.EXTRA_LOGO, item.logo)
                        .putExtra("continue_episode", repo.playlist(item.playlistId)?.let {
                            com.youriptv.app.data.WatchPolicy.key(it, item) })
                        .putExtra("authorization_stamp", s.restrictionStamp()))
                    else Dialogs.choose(a, item.name, listOf("Resume episode", "Play from beginning")) { choice ->
                        play(a, listOf(item), 0, unlocked, choice == 1)
                    }
                }
            }
            onOpened?.invoke()
        }
        if (locked) Dialogs.requirePin(a, "\"${item.group}\" is locked") { go() } else go()
    }

    /** [unlockedGroup] is a locked group the user has just entered the parental PIN for; every other locked group asks again. */
    fun play(a: Activity, queue: List<MediaItem>, index: Int, unlockedGroup: String? = null, fromBeginning: Boolean = false) {
        val catchupIdentity = queue.getOrNull(index)?.takeIf { it.isCatchup && !it.isLocal }
            ?.let { YourIptvApp.instance.repo.playlist(it.playlistId) }
            ?.let(YourIptvApp.instance.repo::sourceIdentity).orEmpty()
        val scopes = queue.map { it.playlistId }.distinct().associateWith { id ->
            YourIptvApp.instance.repo.playlist(id)?.let(com.youriptv.app.data.WatchPolicy::scope).orEmpty()
        }
        YourIptvApp.playQueue = queue.map { item ->
            if (com.youriptv.app.data.WatchPolicy.supports(item)) item.copy(watchScope = item.watchScope.ifBlank { scopes[item.playlistId].orEmpty() }) else item
        }
        a.startActivity(
            Intent(a, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_INDEX, index)
                .putExtra(PlayerActivity.EXTRA_CATCHUP_SOURCE_IDENTITY, catchupIdentity)
                .putExtra("vod_from_beginning", fromBeginning)
                .putExtra(PlayerActivity.EXTRA_UNLOCKED_GROUP, unlockedGroup)
                .putExtra(PlayerActivity.EXTRA_AUTHORIZATION_STAMP, YourIptvApp.instance.settings.restrictionStamp())
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    fun fullscreenPreview(a: Activity): Boolean {
        val session = YourIptvApp.instance.livePlayback
        val item = session.current
        if (item == null || !session.isCurrentAuthorized(item)) {
            Dialogs.toast(a, "Select a channel to start its preview first.")
            return false
        }
        val queue = session.queue
        val index = queue.indexOfFirst { it.playlistId == item.playlistId && it.url == item.url }
        if (index < 0) {
            Dialogs.toast(a, "The preview channel is no longer in the playback list.")
            return false
        }
        YourIptvApp.playQueue = queue
        a.startActivity(
            Intent(a, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_INDEX, index)
                .putExtra(PlayerActivity.EXTRA_UNLOCKED_GROUP, session.unlockedGroup(item))
                .putExtra(PlayerActivity.EXTRA_AUTHORIZATION_STAMP, YourIptvApp.instance.settings.restrictionStamp())
                .putExtra(PlayerActivity.EXTRA_FROM_PREVIEW, true)
        )
        return true
    }

    fun externalPlayer(a: Activity, url: String, title: String) {
        if (!com.youriptv.app.data.SecureTransport.canHandOffMedia(url)) {
            Dialogs.toast(a, com.youriptv.app.data.SecureTransport.NETWORK_URL_REQUIRED)
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*").putExtra("title", title)
        // The chooser never throws when nothing can play the stream, and Android TV adds a framework stub that only
        // says "You don't have an app that can do this". Ignore stubs and check first (needs <queries> in the manifest).
        val handlers = a.packageManager.queryIntentActivities(intent, 0).map { it.activityInfo }
        val stubs = handlers.filter { it.packageName.endsWith(".frameworkpackagestubs") }
        val scheme = Uri.parse(url).scheme?.lowercase()
        if (scheme in setOf("http", "https", "rtmp", "rtsp") && handlers.size == stubs.size) {
            Dialogs.toast(a, "No external video player is installed on this device.")
            return
        }
        val chooser = Intent.createChooser(intent, "Open with")
        if (stubs.isNotEmpty()) {
            chooser.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, stubs.map { ComponentName(it.packageName, it.name) }.toTypedArray())
        }
        try {
            a.startActivity(chooser)
        } catch (_: ActivityNotFoundException) {
            Dialogs.toast(a, "No external video player is installed on this device.")
        }
    }

    fun describeError(e: Throwable): String = when (e) {
        is HttpException -> e.message.orEmpty()
        is UnknownHostException -> "Cannot reach the server (unknown host). Check the URL and your network connection."
        is SocketTimeoutException -> "The provider did not respond in time. Try again later."
        is ConnectException -> "Could not connect to the provider. Check the URL, port, and your network connection."
        is SSLException -> "Secure connection to the provider failed (${e.message})."
        is FileNotFoundException -> "The provider returned 'not found'. Check the URL."
        is JSONException -> "The provider returned unexpected data. Check the server URL and credentials."
        is OutOfMemoryError -> "The playlist is too large for this device's memory."
        else -> e.message ?: e.javaClass.simpleName
    }
}

object Refresher {
    /**
     * Refreshes a playlist and then its guide. Returns a warning when only the guide failed.
     * Legacy protected screens join the same app-owned work as public controls and jobs.
     * The awaiting screen owns its progress observer; its cancellation cannot cancel shared work.
     */
    suspend fun refreshAll(p: Playlist, progress: (String) -> Unit): String? {
        val coordinator = YourIptvApp.instance.refreshCoordinator
        val result = coordinator.awaitRequest(p.id, coordinator.requestPlaylist(p.id), progress)
        if (!result.success && !result.catalogUpdated) throw IllegalStateException(result.message)
        return result.message.takeUnless { result.success }
    }

    suspend fun refreshEpg(p: Playlist, progress: (String) -> Unit): String? {
        val coordinator = YourIptvApp.instance.refreshCoordinator
        val result = coordinator.awaitRequest(p.id, coordinator.requestEpg(p.id), progress)
        return result.message.takeUnless { result.success }
    }
}
